import { RolesConst } from './roles.const.enum';

describe('RolesConst', () => {
  it('should create an instance', () => {
    expect(new RolesConst()).toBeTruthy();
  });
});
