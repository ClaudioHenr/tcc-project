export class RolesConst {
}

export enum AppRoles {
    PROFESSOR = 'ROLE_PROFESSOR',
    STUDENT = 'ROLE_STUDENT'
}