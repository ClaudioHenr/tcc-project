export interface AuthResponse {
    token: string;
}