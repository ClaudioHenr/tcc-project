export interface answer {
    id: number;
    answer: string;
    id_exercise: number;
    id_professor: number;
  }