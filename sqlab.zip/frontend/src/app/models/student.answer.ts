export interface studentAnswer {
    id: number;
    answer: string;
    is_correct: string;
    timestamp: boolean;
    id_exercise: boolean;
    id_student: number;
    id_list: number;
  }