export interface professor {
    id: number;
    name: string;
    email: string;
    registration: string;
    password: string;
  }