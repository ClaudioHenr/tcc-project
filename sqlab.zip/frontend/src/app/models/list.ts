export interface list {
    id: number;
    title: string;
    description: string;
    exerciseIds: number[];
    dueDate?: Date;
 }