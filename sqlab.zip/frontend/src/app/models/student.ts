export interface student {
    id: number;
    name: string;
    email: string;
    registration: string;
    password: string;
  }