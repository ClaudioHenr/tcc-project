export interface grade {
    id: number;
    name: string;
    code: string;
    description?: string;
    idProfessor?: number;
  }