export const environment = {
    production: true,
    apiUrl: 'http://localhost:8080',
    mockData: false, // Alterado: Definido como 'false' para usar dados reais em produção
};