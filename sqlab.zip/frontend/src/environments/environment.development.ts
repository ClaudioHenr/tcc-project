export const environment = {
    production: false,
    apiUrl: "http://localhost:8080",
    mockData: false, // Alterado: Definido como 'false' para usar dados reais durante o desenvolvimento
};