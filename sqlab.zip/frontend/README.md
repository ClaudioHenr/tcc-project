# SqlabFront

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 17.2.1.

Tailwind versão 3
Flowbite

Acrescentado proxy.conf.json para lidar com erro de CORS

```
"options": {
    "proxyConfig": "proxy.conf.json"
},
```

