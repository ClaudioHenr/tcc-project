package br.com.net.sqlab_backend;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SqlabBackendApplicationTests {

	// @Test
	// void contextLoads() {
	// }

}
