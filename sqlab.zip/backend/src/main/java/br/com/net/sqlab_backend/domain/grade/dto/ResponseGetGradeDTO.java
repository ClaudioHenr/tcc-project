package br.com.net.sqlab_backend.domain.grade.dto;

public record ResponseGetGradeDTO(

    Long id,

    String name, 

    String subject,

    String cod

) {
    
}
