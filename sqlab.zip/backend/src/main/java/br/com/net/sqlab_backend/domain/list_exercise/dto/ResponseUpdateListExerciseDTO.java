package br.com.net.sqlab_backend.domain.list_exercise.dto;

public record ResponseUpdateListExerciseDTO(

    Long id,

    String title,

    String description

) {
    
}
