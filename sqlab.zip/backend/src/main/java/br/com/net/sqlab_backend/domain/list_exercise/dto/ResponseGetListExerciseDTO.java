package br.com.net.sqlab_backend.domain.list_exercise.dto;

public record ResponseGetListExerciseDTO(
    
    Long id,

    String title,

    String description

) {


}
