package br.com.net.sqlab_backend.domain.exercises.enums;

public enum ExerciseType {
    SELECT,
    INSERT,
    UPDATE,
    DELETE,
    CREATE,
    DROP,
    ALTER;
}
